export default function ProblemsPanel() {
    return (
        <div className="rounded-3xl border border-white/10 bg-white/5 p-10">
            <h1 className="text-3xl font-bold">Problems</h1>
        </div>
    );
}