export default function DashboardPanel() {
    return (
        <div className="rounded-3xl border border-white/10 bg-white/5 p-10">
            <h1 className="text-3xl font-bold">Dashboard</h1>
        </div>
    );
}